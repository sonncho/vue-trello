<template>
    <div>
        Page not Found
    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>

</style>