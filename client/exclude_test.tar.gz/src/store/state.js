const state = {
    isAddBoard: false,
    boards: [],
    token: null, //인증여보를 체크하는 state
}

export default state